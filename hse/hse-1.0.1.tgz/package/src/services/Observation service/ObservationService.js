import { OBSERVATION_SCREEN_TAGS } from '../../config/constants';

// Import button handlers from ObservationButtonHandlers
import {
  handleViewRejectReasonButton,
  handleRejectButton,
  handleConfirmButton,
  handleCancelButton,
  handleCloseButton,
  handleEntryCompleteButton,
  handleRewardEntryCompleteButton,
  handleRejectReasonOkButton,
  setPendingRejectObservation,
  setPendingRejectForModule,
  clearPendingRejectObservation,
} from './ObservationButtonHandlers';

// RQ_HSE_13_3_26_1_43: CAR reject/cancel pending mechanism
import { getPendingRejectCAR, clearPendingRejectCAR, handleRejectReasonOkForCAR } from '../../utils/carCustomButtons.js';
// RQ_HSE_12_4_26_00_40 — corrective-action account reject (rejectCARTXN) after HSE_RJCTRSN OK
import {
  getPendingFoundationCarReject,
  clearPendingFoundationCarReject,
  handleRejectReasonOkForFoundationCarTxn,
} from '../../utils/carFoundationTxnButtons.js';
// RQ_HSE_12_4_26_00_40 — GAP-2/3/4: Layer 2 reject (Confirmation, Job Verification, Follow-Up Visit)
import {
  getPendingLayer2Reject,
  clearPendingLayer2Reject,
  handleRejectReasonOkForLayer2,
} from '../../utils/carLayer2Buttons.js';

// Import tab management functions from ObservationTabManagement
// RQ_HSE_5_4_26_14_19 — re-export applyObservationCommentsSourceScreen for Comments tab SRCSCRN
import {
  isObservationTabsEnabled,
  manageObservationTabs,
  manageCommentsTabToolBar,
  applyObservationCommentsSourceScreen, // RQ_HSE_5_4_26_14_19
} from './ObservationTabManagement';

// Re-export for backward compatibility and for ModuleButtonHandlers (reject reason flow)
export {
  isObservationTabsEnabled,
  manageObservationTabs,
  manageCommentsTabToolBar,
  applyObservationCommentsSourceScreen,
  setPendingRejectObservation,
  setPendingRejectForModule,
  clearPendingRejectObservation,
};

/**
 * ObservationService.js
 * 
 * Main entry point for Observation module functionality.
 * Routes button clicks to appropriate handlers and provides utility functions.
 * 
 * This file has been refactored to delegate to:
 * - ObservationButtonHandlers.js: All button click handlers
 * - ObservationTabManagement.js: Tab enabling/disabling and Comments tab management
 *
 * RQ_HSE_5_4_26_14_19 — exports applyObservationCommentsSourceScreen (Comments tab SRCSCRN).
 */

/**
 * Check if a screen tag belongs to the Observation module
 * @param {string} screenTag - The screen tag to check
 * @returns {boolean} - True if the screen is an observation screen
 */
export function isObservationScreen(screenTag) {
  if (!screenTag) return false;
  
  const normalizedTag = screenTag.toString().toUpperCase();
  return OBSERVATION_SCREEN_TAGS.some(tag => normalizedTag === tag.toUpperCase());
}

/**
 * Send button click event to Web_HSE backend
 * Handles Reject, View Reject Reason, Confirm, Cancel, and Entry Complete buttons on Observation module screens
 * 
 * This is the main routing function that delegates to specific button handlers.
 * 
 * @param {string} buttonName - The button name/ID to log
 * @param {string} screenTag - The screen tag to check if it's an observation screen
 * @param {Object} eventObj - The full event object containing fullRecord, strScrTag, etc.
 * @param {Object} devInterface - Object containing devInterface functions (FormGetField, executeSQL, etc.)
 */
export function sendButtonClickToBackend(buttonName, screenTag, eventObj = {}, devInterface = {}) {
  // Debug logging to see what's being passed
  console.log('[Web_HSE Debug] Button clicked:', {
    buttonName,
    screenTag,
    isObservationScreen: isObservationScreen(screenTag)
  });
  
  // Normalize button name for comparison (buttonName is already normalized to uppercase in buttonEvents.js)
  const normalizedButton = buttonName ? buttonName.toString().toUpperCase() : '';
  const normalizedScreenTag = screenTag ? screenTag.toString().toUpperCase() : '';
  
  // C++: CRejectReason::DisplayCustomButtonClicked - handles RJCTRSN_BTN_OK
  // Handle reject reason screen OK button (this is part of observation module flow)
  // Check both possible screen tag casings: HSE_TGRJCTRSN (uppercase) or HSE_TGRJCTRSN (mixed case from config)
  if ((normalizedScreenTag === 'HSE_TGRJCTRSN' || normalizedScreenTag === 'HSE_TGRJCTRSN') && normalizedButton === 'RJCTRSN_BTN_OK') {
    console.log('[Web_HSE] ✓ Reject reason screen OK button (RJCTRSN_BTN_OK) clicked!');
    // RQ_HSE_12_4_26_00_40 — GAP-2/3/4: Layer 2 reject (Confirmation, Job Verification, Follow-Up Visit)
    if (getPendingLayer2Reject()) {
      void handleRejectReasonOkForLayer2(devInterface, eventObj);
    // RQ_HSE_12_4_26_00_40 — foundation CAR txn reject (Actions Received / Under Execution) before header CAR reject
    } else if (getPendingFoundationCarReject()) {
      // RQ_HSE_12_4_26_00_40 — pass RJCTRSN screen fullRecord for rejectCARTXN 5th-arg parity
      void handleRejectReasonOkForFoundationCarTxn(devInterface, eventObj);
    } else if (getPendingRejectCAR()) {
      // RQ_HSE_13_3_26_1_43: check CAR pending reject/cancel first; fall back to observation handler
      handleRejectReasonOkForCAR(devInterface, eventObj);
    } else {
      handleRejectReasonOkButton(devInterface);
    }
    return;
  }
  
  // C++: CRejectReason::DisplayCustomButtonClicked - handles RJCTRSN_BTN_CANCEL
  // Check both possible screen tag casings: HSE_TGRJCTRSN (uppercase) or HSE_TGRJCTRSN (mixed case)
  if ((normalizedScreenTag === 'HSE_TGRJCTRSN' || normalizedScreenTag === 'HSE_TGRJCTRSN') && normalizedButton === 'RJCTRSN_BTN_CANCEL') {
    console.log('[Web_HSE] Reject reason screen Cancel button clicked. Clearing pending rejection.');
    // RQ_HSE_13_3_26_1_43: clear both observation and CAR pending reject
    // RQ_HSE_12_4_26_00_40
    clearPendingRejectObservation();
    clearPendingRejectCAR();
    clearPendingFoundationCarReject();
    clearPendingLayer2Reject(); // RQ_HSE_12_4_26_00_40 — GAP-2/3/4
    return;
  }
  
  // Only process if this is an observation screen
  if (!isObservationScreen(screenTag)) {
    console.log('[Web_HSE Debug] Not an observation screen, skipping');
    return;
  }
  
  // Handle buttons: View Reject Reason, Reject, Confirm, Cancel, Close, Entry Complete
  // Button names follow pattern:
  // - *_VWRJCTRSNS (View Reject Reasons on tracing tab)
  // - NRSTMISCENT_RJC (Reject)
  // - NRSTMISCENT_ACP (Confirm/Accept)
  // - NRSTMISCENT_CNCL (Cancel)
  // - NRSTMISCENT_CLS (Close)
  // - NRSTMISCENT_ENTCMPLT (Entry Complete)
  if (normalizedButton.endsWith('_VWRJCTRSNS')) {
    // RQ_HSM_22_12_09_57: View Reject Reason (Observation Entry)
    // RQ_HSM_22_12_11_10: Handle View Reject Reason Custom Button
    // ClickUp Task: https://app.clickup.com/t/86c76vt58
    handleViewRejectReasonButton(buttonName, screenTag, eventObj, devInterface);
  } else if (normalizedButton.includes('_RJC') || normalizedButton.endsWith('_RJC')) {
    // RQ_HSM_22_12_10_50: Handle Reject button (button name contains or ends with _RJC)
    // ClickUp Task: https://app.clickup.com/t/86c76v8yr
    handleRejectButton(buttonName, screenTag, eventObj, devInterface);
  } else if (normalizedButton === 'NRSTMISCENT_ENTCMPLT' || normalizedButton.endsWith('_ENTCMPLT')) {
    // RQ_HSM_22_12_25_11_43: Handle Reward Entry Completed Custom Button
    // RQ_HSM_22_12_25_09_35: Implement Entry Completed
    // The same button name is used for both Entry and Reward screens, but they have different handlers
    // C++: NearMissReward::DisplayCustomButtonClicked handles NRSTMISCENT_ENTCMPLT for reward screen
    //      NearMissEntryCategory::DisplayCustomButtonClicked handles it for entry screen
    // Check if this is the Reward screen (normalizedScreenTag is already uppercase)
    if (normalizedScreenTag.includes('RWARD') || normalizedScreenTag === 'HSE_TGNRMISRWARD') {
      // This is the Reward screen - use reward handler
      handleRewardEntryCompleteButton(buttonName, screenTag, eventObj, devInterface);
    } else {
      // This is the Entry screen - use entry handler
      handleEntryCompleteButton(buttonName, screenTag, eventObj, devInterface);
    }
  } else if (normalizedButton === 'NRSTMISCENT_ACP' || normalizedButton.endsWith('_ACP')) {
    // RQ_HSM_22_12_10_48: Handle Confirm/Accept button
    // ClickUp Task: https://app.clickup.com/t/86c76v5ze
    handleConfirmButton(buttonName, screenTag, eventObj, devInterface);
  } else if (normalizedButton === 'NRSTMISCENT_CNCL' || normalizedButton.endsWith('_CNCL')) {
    // RQ_HSM_22_12_10_55: Handle Cancel Custom Button
    // ClickUp Task: https://app.clickup.com/t/86c76v9yr
    handleCancelButton(buttonName, screenTag, eventObj, devInterface);
  } else if (normalizedButton === 'NRSTMISCENT_CLS' || normalizedButton.endsWith('_CLS')) {
    // BUG_HSE_HSM_14_3_26: Observation Approval Close – desktop parity (save, key/employee checks, closeNearMissTXN, refresh)
    // (RQ_HSM_22_12_11_28) Handle Close Custom Button
    handleCloseButton(buttonName, screenTag, eventObj, devInterface);
  } else {
    // Other buttons are not handled
    console.log('[Web_HSE Debug] Button not handled. Button name:', normalizedButton);
  }
}
