import { toast } from "react-toastify";
// BUG_HSE_HSM_14_3_26_17_33: use getScreenCaption so reject tracing tab Source Screen is caption (desktop behaviour)
import { getScreenCaption } from "../ModuleButtonHandlers/moduleButtonHandlersUtils.js";

/**
 * ObservationButtonHandlers.js
 * 
 * Handles all button click events for Observation module screens
 * 
 * Requirements:
 * - RQ_HSM_22_12_09_57: View Reject Reason (Observation Entry)
 * - RQ_HSM_22_12_10_48: Handle Confirm Custom Button
 * - RQ_HSM_22_12_10_50: Handle Reject Custom Button
 * - RQ_HSM_22_12_10_55: Handle Cancel Custom Button
 * - RQ_HSM_22_12_11_10: Handle View Reject Reason Custom Button
 * - RQ_HSM_22_12_11_28: Handle Close Custom Button
 * - RQ_HSM_22_12_25_09_35: Implement Entry Completed
 * - RQ_HSM_22_12_25_11_43: Handle Reward Entry Completed Custom Button
 */

// Store pending reject execution info (module-level). Supports Observation, PTW, Incident, Risk Assessment, Site Survey, Vehicle Accident, Awareness, Rescue Plan cancel.
// moduleType: 'OBSERVATION' | 'PTW' | 'INCIDENT' | 'RISK' | 'SITE_SURVEY' | 'VEHICLE_ACCIDENT' | 'AWARENESS' | 'RESCUE_CANCEL'
// RQ_HSE_23_3_26_17_05, RQ_HSE_23_3_26_22_44 (SITE_SURVEY)
let pendingRejectObservation = null;

export function setPendingRejectObservation(observationInfo) {
  pendingRejectObservation = observationInfo ? { ...observationInfo, moduleType: observationInfo.moduleType || 'OBSERVATION' } : null;
}

export function clearPendingRejectObservation() {
  pendingRejectObservation = null;
}

/**
 * Set pending reject for non-Observation modules (PTW, Incident, Risk Assessment, Vehicle Accident, Awareness).
 * When user clicks OK on reject reason screen, the appropriate SP or update will run.
 * @param {string} moduleType - 'PTW' | 'INCIDENT' | 'RISK' | 'VEHICLE_ACCIDENT' | 'POTENTIAL_HAZARD' | 'LOSS_ACCIDENT' | 'AWARENESS'
 * @param {string} keyFieldValue - record key
 * @param {string} sourceScreenName - form/screen tag for SourceScreenName
 * @param {Object} devInterface - getUserName, executeSQLPromise/executeSQL, refreshData, toast
 */
export function setPendingRejectForModule(moduleType, keyFieldValue, sourceScreenName, devInterface) {
  const executeSQLAsync = devInterface?.executeSQLPromise || devInterface?.executeSQL;
  if (!executeSQLAsync || !keyFieldValue) return;
  pendingRejectObservation = {
    moduleType,
    keyFieldValue: String(keyFieldValue),
    formTag: sourceScreenName,
    sourceScreenName: sourceScreenName || '',
    getUserName: devInterface.getUserName,
    executeSQLAsync,
    refreshData: devInterface.refreshData,
    toast: devInterface.toast,
  };
}

/**
 * Handle View Reject Reason custom button click on Observation tracing tab
 * RQ_HSM_22_12_09_57: View Reject Reason (Observation Entry)
 * RQ_HSM_22_12_11_10: Handle View Reject Reason Custom Button
 * ClickUp Task: https://app.clickup.com/t/86c76vt58
 * Mirrors C++: CHSEMSCommonCategory::viewRejectReason for buttons ending with _VWRJCTRSNS
 * - Opens HSE_TGRJCTRSN in (effectively) locked mode to show existing reject reasons
 * @param {string} buttonName - The button name (e.g. NRSTMISCENTTRC_VWRJCTRSNS)
 * @param {string} screenTag - The screen tag (owner screen)
 * @param {Object} eventObj - The full event object
 * @param {Object} devInterface - Object containing devInterface functions
 */
export async function handleViewRejectReasonButton(buttonName, screenTag, eventObj, devInterface) {
  try {
    const { FormGetField, openScr } = devInterface;

    if (!openScr) {
      console.error('[Web_HSE] Missing required devInterface functions for View Reject Reason button');
      toast.error('System error: Required functions not available');
      return;
    }

    const rawBtnName = buttonName ? buttonName.toString() : '';
    if (!rawBtnName.toUpperCase().endsWith('_VWRJCTRSNS')) {
      console.warn('[Web_HSE] View Reject Reason handler called for non _VWRJCTRSNS button:', rawBtnName);
      return;
    }

    // Derive table and field names from button name
    // C++:
    //   strTableName = "HSE_" + (BtnName without "_VWRJCTRSNS")
    //   strActionType = <base> + "_ACCDESC"
    //   strFieldName  = <base> + "_MAINLNK"
    //   strLinkField  = <base> + "_LNK"
    const baseName = rawBtnName.replace(/_VWRJCTRSNS$/i, '');

    // Prefer values from the selected tracing row (fullRecord) instead of FormGetField,
    // because tracing tab fields are part of a sub-grid.
    const { fullRecord: fullRecordArr } = eventObj || {};
    const firstRecord = Array.isArray(fullRecordArr)
      ? fullRecordArr[0]
      : fullRecordArr || {};

    let linkValue =
      firstRecord?.NRSTMISCENTTRC_LNK ??
      firstRecord?.NRSTMISCENTTRC_LNK?.toString?.() ??
      '';

    // Normalize link value to string to safely use replace()
    if (linkValue !== null && linkValue !== undefined) {
      linkValue = String(linkValue);
    }

    if (!linkValue) {
      toast.warning('Unable to find linked Observation number for reject reasons.');
      return;
    }

    // For Observation module the base module name is NRSTMISCENT
    // C++: strModulefrmSource is used in "RJCTRSN_MODULETYPE like '<src>%'" (to match L1/L2)
    const moduleSource = 'NRSTMISCENT';

    // Use plain WHERE clause for list screen criteria (server builds full SELECT)
    // Remove any extra whitespace/newlines to ensure clean SQL
    const criteria = `WHERE RJCTRSN_LINKWITHMAIN = '${linkValue.replace(/'/g, "''")}' AND RJCTRSN_MODULETYPE LIKE '${moduleSource.replace(/'/g, "''")}%'`.trim();

    console.log('[Web_HSE] Opening View Reject Reason screen with criteria:', criteria);
    console.log('[Web_HSE] Screen tag:', 'HSE_TGRjctRsn', 'Link value:', linkValue);

    // Open reject reason screen in read-only/locked mode
    // C++: setgbOpenRejectScreenLocked(true) then ShowScreen(..., true) for locked
    // Use correct screen tag from config: HSE_TGRjctRsn (not HSE_TGRJCTRSN)
    // Use 'list' mode with bLockScr=true (8th parameter) to make it read-only
    // Pass empty string for criteria to let server handle it, or pass as WHERE clause
    const rejectReasonScreenTag = 'HSE_TGRjctRsn'; // Match the exact tag from header.json
    openScr(rejectReasonScreenTag, {}, criteria, 'list', false, {}, false, true);
  } catch (error) {
    console.error('[Web_HSE] Error in handleViewRejectReasonButton:', error);
    toast.error('An error occurred while opening reject reasons.');
  }
}

/**
 * Handle Reject button click
 * RQ_HSM_22_12_10_50: Handle Reject Custom Button
 * ClickUp Task: https://app.clickup.com/t/86c76v8yr
 * Implements the logic from NearMissCategory::DisplayCustomButtonClicked for NRSTMISCENT_RJC
 * @param {string} buttonName - The button name
 * @param {string} screenTag - The screen tag
 * @param {Object} eventObj - The full event object
 * @param {Object} devInterface - Object containing devInterface functions
 */
export async function handleRejectButton(buttonName, screenTag, eventObj, devInterface) {
  // (RQ_HSM_22_12_11_21) Handle Reject Custom Button
  try {
    const {
      FormGetField,
      executeSQL,
      executeSQLPromise,
      getUserName,
      refreshData,
      openScr,
      doToolbarAction,
    } = devInterface;

    // Validate required functions
    if (
      !FormGetField ||
      (!executeSQL && !executeSQLPromise) ||
      !getUserName ||
      !refreshData ||
      !openScr
    ) {
      console.error('[Web_HSE] Missing required devInterface functions for Reject button');
      toast.error('System error: Required functions not available');
      return;
    }

    const executeSQLAsync = executeSQLPromise || executeSQL;

    // Extract event data
    const { fullRecord: fullRecordArr, fullRecordArrKeys } = eventObj || {};

    // Get key field value (Near Miss / Observation number)
    let keyFieldValue = '';
    if (fullRecordArrKeys && fullRecordArrKeys.length > 0) {
      keyFieldValue = fullRecordArrKeys[0].toString();
    } else if (fullRecordArr && fullRecordArr.length > 0) {
      const firstRecord = Array.isArray(fullRecordArr) ? fullRecordArr[0] : fullRecordArr;
      keyFieldValue =
        firstRecord?.NRSTMISCENT_NRSTMISCNUM ||
        firstRecord?.NRSTMISCNUM ||
        '';
    }

    const formTag = screenTag || 'HSE_TGNRSTMISCCNFRMTN';

    // Fallback: read from form if still empty
    if (!keyFieldValue) {
      keyFieldValue =
        FormGetField('HSE_vwNRSTMISCENT', 'NRSTMISCENT_NRSTMISCNUM') ||
        FormGetField(formTag, 'NRSTMISCENT_NRSTMISCNUM') ||
        '';
    }

    if (!keyFieldValue) {
      toast.warning('Unable to find Observation number. Please select a record first.');
      return;
    }

    // Determine module type based on screen tag
    // C++: rejectRecord() sets "NRSTMISCENT-L1" for confirmation screen, "NRSTMISCENT-L2" for follow-up
    let moduleType = 'NRSTMISCENT-L1'; // Default for confirmation screen
    if (formTag === 'HSE_TGNRSTMISCCNFRMTN') {
      moduleType = 'NRSTMISCENT-L1';
    } else if (formTag === 'HSE_TGNRSTMISCFLWUP') {
      moduleType = 'NRSTMISCENT-L2';
    }

    // C++: ShowRejectreason() opens the reject reason screen
    // Use openScr with the reject reason screen tag and default values
    // The screen will handle the dialog/prompt internally
    const rejectReasonScreenTag = 'HSE_TGRjctRsn';
    const criteria = `SELECT * FROM HSE_RJCTRSN WHERE (RJCTRSN_LINKWITHMAIN='${keyFieldValue.replace(/'/g, "''")}') AND (RJCTRSN_MODULETYPE='${moduleType}') AND (ISNULL(RJCTRSN_TRACINGLNK, 0) = 0)`;
    
    // Set default values for the reject reason screen
    // C++: FormSetField("HSE_RJCTRSN","RJCTRSN_LINKWITHMAIN",strKeyValForRjctScr)
    //      FormSetField("HSE_RJCTRSN","RJCTRSN_MODULETYPE",strRjctRsnSrcScr)
    const defValObj = {
      RJCTRSN_LINKWITHMAIN: keyFieldValue,
      RJCTRSN_MODULETYPE: moduleType,
      RJCTRSN_TRACINGLNK: 0,
    };

    // Check if reject reason already exists before opening screen
    // C++: After screen closes, checks getgbUpdateRejectedRecord() flag
    // In JS: We'll check if a reject reason was added after screen opens
    const checkRejectReasonBeforeSql = `SELECT COUNT(0) FROM HSE_RJCTRSN WHERE RJCTRSN_MODULETYPE = '${moduleType.replace(/'/g, "''")}' AND RJCTRSN_LINKWITHMAIN = '${keyFieldValue.replace(/'/g, "''")}' AND ISNULL(RJCTRSN_TRACINGLNK, 0) = 0`;
    
    let rejectReasonCountBefore = 0;
    try {
      const resultBefore = await executeSQLAsync(checkRejectReasonBeforeSql);
      if (resultBefore && resultBefore.length > 0 && resultBefore[0]) {
        const countObj = resultBefore[0];
        rejectReasonCountBefore = parseInt(Object.values(countObj)[0] || 0, 10);
      }
    } catch (error) {
      console.warn('[Web_HSE] Error checking reject reason count before:', error);
    }

    // Store info for executing rejectObservation after reject reason screen OK button is clicked
    // C++: After reject reason screen closes, checks getgbUpdateRejectedRecord() flag
    // In JS: We use ButtonClicked event to detect when RJCTRSN_BTN_OK is clicked
    // C++: setgbUpdateRejectedRecord(false) is set initially, then true when OK is clicked
    // BUG_HSE_HSM_14_3_26_17_33: pass screen caption as sourceScreenName so tracing tab Source Screen matches desktop (GetScrCptnByTag)
    const sourceScreenName = getScreenCaption(formTag) || formTag;
    setPendingRejectObservation({
      keyFieldValue: keyFieldValue.toString(), // Ensure it's a string for the stored procedure
      formTag,
      sourceScreenName,
      getUserName,
      executeSQLAsync,
      refreshData,
      toast,
    });

    // Open the reject reason screen - it has its own built-in dialog
    // C++: ShowRejectreason(strCriteria) -> opens HSE_TGRjctRsn screen
    console.log('[Web_HSE] Opening reject reason screen:', {
      screenTag: rejectReasonScreenTag,
      observationNumber: keyFieldValue,
      moduleType: moduleType,
    });
    
    openScr(rejectReasonScreenTag, {}, criteria, 'edit', true, defValObj);

    // C++: After screen closes, if getgbUpdateRejectedRecord() == true, execute rejectObservation
    // In JS: We use ButtonClicked event to detect when RJCTRSN_BTN_OK is clicked
    // The stored procedure will be executed automatically when OK button is clicked
    console.log('[Web_HSE] Reject reason screen opened. Waiting for OK button click (RJCTRSN_BTN_OK)...');
    console.log('[Web_HSE] Pending rejection info stored:', {
      observationNumber: keyFieldValue,
      screenTag: formTag,
    });
  } catch (error) {
    console.error('[Web_HSE] Error in handleRejectButton:', error);
    toast.error('An error occurred while processing the Reject action');
  }
}

/**
 * Handle Confirm (Accept) button click
 * RQ_HSM_22_12_10_48: Handle Confirm Custom Button
 * ClickUp Task: https://app.clickup.com/t/86c76v5ze
 * Implements the logic from NearMissConfirmationCategory::AcceptNearMiss for NRSTMISCENT_ACP
 * @param {string} buttonName - The button name
 * @param {string} screenTag - The screen tag
 * @param {Object} eventObj - The full event object
 * @param {Object} devInterface - Object containing devInterface functions
 */
export async function handleConfirmButton(buttonName, screenTag, eventObj, devInterface) {
  try {
    const {
      FormGetField,
      executeSQL,
      executeSQLPromise,
      getUserName,
      refreshData,
      AskYesNoMessage,
      doToolbarAction,
    } = devInterface;

    // Validate required functions
    if (
      !FormGetField ||
      (!executeSQL && !executeSQLPromise) ||
      !getUserName ||
      !refreshData ||
      !AskYesNoMessage
    ) {
      console.error('[Web_HSE] Missing required devInterface functions for Confirm button');
      toast.error('System error: Required functions not available');
      return;
    }

    const executeSQLAsync = executeSQLPromise || executeSQL;

    const formTag = screenTag || 'HSE_TGNRSTMISCCNFRMTN';

    // RQ_HSE_13_3_26_1_43: C++ saves before confirm – DoToolBarAction(TOOLBAR_SAVE, strFormTag, "")
    if (typeof doToolbarAction === 'function') {
      doToolbarAction('SAVE', formTag, '');
    }

    // Extract event data
    const { fullRecord: fullRecordArr, fullRecordArrKeys } = eventObj || {};

    // Get key field value (Near Miss / Observation number)
    let keyFieldValue = '';
    if (fullRecordArrKeys && fullRecordArrKeys.length > 0) {
      keyFieldValue = fullRecordArrKeys[0].toString();
    } else if (fullRecordArr && fullRecordArr.length > 0) {
      const firstRecord = Array.isArray(fullRecordArr) ? fullRecordArr[0] : fullRecordArr;
      keyFieldValue =
        firstRecord?.NRSTMISCENT_NRSTMISCNUM ||
        firstRecord?.NRSTMISCNUM ||
        '';
    }

    // Fallback: read from form if still empty
    if (!keyFieldValue) {
      keyFieldValue =
        FormGetField('HSE_vwNRSTMISCENT', 'NRSTMISCENT_NRSTMISCNUM') ||
        FormGetField(formTag, 'NRSTMISCENT_NRSTMISCNUM') ||
        '';
    }

    if (!keyFieldValue) {
      toast.warning('Unable to find Observation number. Please select a record first.');
      return;
    }

    // Check if there is a new reject reason for this record
    // Equivalent to: IsNewRjcRsnExist('NRSTMISCENT-L1', keyFieldValue)
    const checkRejectSql = `
      SELECT COUNT(0) AS CNT
      FROM HSE_RJCTRSN
      WHERE RJCTRSN_MODULETYPE = 'NRSTMISCENT-L1'
        AND RJCTRSN_LINKWITHMAIN = '${keyFieldValue.replace(/'/g, "''")}'
        AND ISNULL(RJCTRSN_TRACINGLNK, 0) = 0
    `;

    let rejectReasonCount = 0;
    try {
      const rs = await executeSQLAsync(checkRejectSql);
      // WebInfra returns an object with recordset array; fall back gracefully
      const recordset = rs?.recordset || rs?.[0]?.recordset || [];
      if (Array.isArray(recordset) && recordset.length > 0) {
        const row = recordset[0];
        const val = row.CNT ?? row.cnt ?? Object.values(row)[0];
        rejectReasonCount = parseInt(val, 10) || 0;
      }
    } catch (err) {
      console.warn('[Web_HSE] Failed to check reject reasons, proceeding without that check:', err);
    }

    // Build stored procedure call
    // BUG_HSE_HSM_14_3_26_17_33: tracing tab Source Screen must be caption not form tag (desktop uses GetScrCptnByTag).
    const sourceScreenName = getScreenCaption(formTag) || formTag;
    const userName = getUserName() || '';
    const spSql = `EXECUTE confirmNearMissTXN '${keyFieldValue.replace(/'/g, "''")}','${sourceScreenName.replace(
      /'/g,
      "''"
    )}','${userName.replace(/'/g, "''")}'`;

    // If reject reasons exist, ask the user before proceeding
    if (rejectReasonCount > 0) {
      const msg =
        'Reject reason for this record exists.\n\rDo you want to delete it and approve this observation?';
      const confirmed = await AskYesNoMessage('Prompt', msg);
      if (!confirmed) {
        return;
      }
      // RQ_HSE_13_3_26_1_43: C++ deletes pending reject reasons before confirming
      try {
        const deleteRjctSql = `
          DELETE FROM HSE_RJCTRSN
          WHERE RJCTRSN_MODULETYPE = 'NRSTMISCENT-L1'
            AND RJCTRSN_LINKWITHMAIN = '${keyFieldValue.replace(/'/g, "''")}'
            AND ISNULL(RJCTRSN_TRACINGLNK, 0) = 0
        `;
        await executeSQLAsync(deleteRjctSql);
      } catch (delErr) {
        console.error('[Web_HSE] Failed to delete reject reasons:', delErr);
        toast.error('Error deleting reject reasons. Please try again.');
        return;
      }
    }

    try {
      await executeSQLAsync(spSql);
      refreshData('', 'REFRESH_SELECTED');
      toast.success('Observation confirmed successfully');
    } catch (err) {
      console.error('[Web_HSE] Error executing confirmNearMissTXN:', err);
      toast.error('Error confirming observation. Please try again.');
    }
  } catch (error) {
    console.error('[Web_HSE] Error in handleConfirmButton:', error);
    toast.error('An error occurred while processing the Confirm action');
  }
}

/**
 * Handle Cancel button click
 * RQ_HSM_22_12_10_55: Handle Cancel Custom Button
 * ClickUp Task: https://app.clickup.com/t/86c76v9yr
 * Implements the logic from NearMissCategory::DisplayCustomButtonClicked for NRSTMISCENT_CNCL
 * @param {string} buttonName - The button name
 * @param {string} screenTag - The screen tag
 * @param {Object} eventObj - The full event object
 * @param {Object} devInterface - Object containing devInterface functions
 */
export async function handleCancelButton(buttonName, screenTag, eventObj, devInterface) {
  // (RQ_HSM_22_12_11_30) Handle Cancel Custom Button
  try {
    const {
      FormGetField,
      FormSetField,
      executeSQL,
      executeSQLPromise,
      getUserName,
      refreshData,
      AskYesNoMessage,
      doToolbarAction,
    } = devInterface;

    // Validate required functions
    if (
      !FormGetField ||
      !FormSetField ||
      (!executeSQL && !executeSQLPromise) ||
      !getUserName ||
      !refreshData ||
      !AskYesNoMessage ||
      !doToolbarAction
    ) {
      console.error('[Web_HSE] Missing required devInterface functions for Cancel button');
      toast.error('System error: Required functions not available');
      return;
    }

    const executeSQLAsync = executeSQLPromise || executeSQL;
    const formTag = screenTag || 'HSE_TGNRSTMISCCNFRMTN';

    // Get key field value and status from event object first (more reliable)
    const { fullRecord: fullRecordArr, fullRecordArrKeys } = eventObj || {};
    let keyFieldValue = '';
    let currentStatus = '';

    // Try to get values from event object first
    if (fullRecordArrKeys && fullRecordArrKeys.length > 0) {
      keyFieldValue = fullRecordArrKeys[0].toString();
    } else if (fullRecordArr && fullRecordArr.length > 0) {
      const firstRecord = Array.isArray(fullRecordArr) ? fullRecordArr[0] : fullRecordArr;
      keyFieldValue =
        firstRecord?.NRSTMISCENT_NRSTMISCNUM ||
        firstRecord?.NRSTMISCNUM ||
        firstRecord?.NrstMiscEnt_NrstMiscNum ||
        '';
      currentStatus =
        firstRecord?.NRSTMISCENT_RECSTS ||
        firstRecord?.RECSTS ||
        '';
    }

    // Fallback: read from form if still empty
    if (!currentStatus) {
      // Try view name first (most reliable), then form tag
      // Wrap in try-catch to handle cases where form/view doesn't exist
      try {
        currentStatus = FormGetField('HSE_vwNRSTMISCENT', 'NRSTMISCENT_RECSTS') || '';
      } catch (e) {
        // Ignore error, try next option
      }
      if (!currentStatus) {
        try {
          currentStatus = FormGetField(formTag, 'NRSTMISCENT_RECSTS') || '';
        } catch (e) {
          // Ignore error, use empty string
        }
      }
    }

    // C++: Check if status is already 99 (cancelled)
    // Only check if we successfully retrieved the status
    if (currentStatus && (currentStatus === '99' || currentStatus === 99)) {
      toast.info('Record is already cancelled');
      return;
    }

    // C++: MessageBox(NULL,"Are you sure to cancel the observation - (Yes/No)?","Prompt",MB_YESNO | MB_ICONEXCLAMATION |MB_TASKMODAL);
    const confirmed = await AskYesNoMessage(
      'Prompt',
      'Are you sure to cancel the observation - (Yes/No)?'
    );

    if (!confirmed) {
      // User clicked No, ignore the action
      return;
    }

    // C++: FormSetField(strForm_Tag,"NRSTMISCENT_RECSTS","99");
    FormSetField(formTag, 'NRSTMISCENT_RECSTS', '99');

    // Get observation number (use value from event if we already have it)
    // C++: FormGetField(strForm_Tag,"NrstMiscEnt_NrstMiscNum")
    if (!keyFieldValue) {
      // Wrap in try-catch to handle cases where form/view doesn't exist
      try {
        keyFieldValue = FormGetField('HSE_vwNRSTMISCENT', 'NRSTMISCENT_NRSTMISCNUM') || '';
      } catch (e) {
        // Ignore error, try next option
      }
      if (!keyFieldValue) {
        try {
          keyFieldValue = FormGetField(formTag, 'NrstMiscEnt_NrstMiscNum') || '';
        } catch (e) {
          // Ignore error, try next option
        }
      }
      if (!keyFieldValue) {
        try {
          keyFieldValue = FormGetField(formTag, 'NRSTMISCENT_NRSTMISCNUM') || '';
        } catch (e) {
          // Ignore error, use empty string
        }
      }
    }

    const linkFieldVal = keyFieldValue;

    if (!linkFieldVal) {
      toast.warning('Unable to find Observation number. Please save the record first.');
      return;
    }

    // Get screen name based on form tag
    // C++:
    //   if (strForm_Tag=="HSE_TGNRSTMISCCNFRMTN") strScreenName="Observation Review";
    //   else if (strForm_Tag=="HSE_TGNRSTMISCFLWUP") strScreenName="Observation Approval";
    let screenName = '';
    const normalizedFormTag = formTag.toUpperCase();
    if (normalizedFormTag === 'HSE_TGNRSTMISCCNFRMTN' || normalizedFormTag.includes('CNFRMTN')) {
      screenName = 'Observation Review';
    } else if (normalizedFormTag === 'HSE_TGNRSTMISCFLWUP' || normalizedFormTag.includes('FLWUP')) {
      screenName = 'Observation Approval';
    } else {
      screenName = 'Observation Entry'; // Default fallback
    }

    // Get user name
    const userName = getUserName() || '';

    // C++: Insert tracing record
    // C++: strSQL.Format("insert into HSE_NRSTMISCENTTRC (NRSTMISCENTTRC_DATTIM,NRSTMISCENTTRC_ACCDESC,NRSTMISCENTTRC_LNK,NRSTMISCENTTRC_ENTUSR,SRCSCRN) values (getdate(),'Canceled',%s,'%s','%s')",linkFieldVal,strUserName,strScreenName);
    // Note: linkFieldVal is inserted as a number (no quotes), userName and screenName are strings (with quotes)
    // Ensure linkFieldVal is a number (remove any quotes or convert to number)
    const linkFieldValNum = typeof linkFieldVal === 'string' ? linkFieldVal.replace(/['"]/g, '') : linkFieldVal;
    const insertTracingSql = `INSERT INTO HSE_NRSTMISCENTTRC (NRSTMISCENTTRC_DATTIM,NRSTMISCENTTRC_ACCDESC,NRSTMISCENTTRC_LNK,NRSTMISCENTTRC_ENTUSR,SRCSCRN) VALUES (getdate(),'Canceled',${linkFieldValNum},'${userName.replace(/'/g, "''")}','${screenName.replace(/'/g, "''")}')`;

    console.log('[Web_HSE] Inserting Cancel tracing record with SQL:', insertTracingSql);
    console.log('[Web_HSE] Link field value:', linkFieldValNum, 'Type:', typeof linkFieldValNum);

    try {
      // Get timestamp just before inserting "Canceled" record
      // This helps us identify and delete any "Completed" records inserted after
      const getMaxTimestampSql = `SELECT MAX(NRSTMISCENTTRC_DATTIM) as MaxTime FROM HSE_NRSTMISCENTTRC WHERE NRSTMISCENTTRC_LNK = ${linkFieldValNum}`;
      let maxTimestampBefore = null;
      try {
        const maxTimeResult = await executeSQLAsync(getMaxTimestampSql);
        if (maxTimeResult?.recordsets?.[0]?.[0]?.MaxTime) {
          const timestampValue = maxTimeResult.recordsets[0][0].MaxTime;
          // SQL Server returns datetime as a string or Date object - handle both
          if (timestampValue instanceof Date) {
            maxTimestampBefore = timestampValue.toISOString().replace('T', ' ').substring(0, 23);
          } else if (typeof timestampValue === 'string') {
            maxTimestampBefore = timestampValue;
          } else {
            // Convert to string if it's some other format
            maxTimestampBefore = String(timestampValue);
          }
          console.log('[Web_HSE] Max timestamp before Cancel:', maxTimestampBefore, typeof maxTimestampBefore);
        }
      } catch (e) {
        console.warn('[Web_HSE] Could not get max timestamp:', e);
      }

      const insertResult = await executeSQLAsync(insertTracingSql);
      console.log('[Web_HSE] ✓ Tracing record inserted for cancelled observation. Result:', insertResult);

      // C++: DoToolBarAction(TOOLBAR_SAVE,strForm_Tag,"");
      doToolbarAction('SAVE', formTag, '');

      // After save, delete any "Completed" record that was inserted after our "Canceled" record
      // The save action might insert a "Completed" record, but we want "Canceled" to be the final action
      // Use a delay to ensure save completes, then delete "Completed" records and refresh
      setTimeout(async () => {
        try {
          let deletedRows = 0;
          if (maxTimestampBefore) {
            // maxTimestampBefore is already a SQL datetime string, use it directly
            const deleteCompletedSql = `DELETE FROM HSE_NRSTMISCENTTRC 
                                        WHERE NRSTMISCENTTRC_LNK = ${linkFieldValNum} 
                                        AND NRSTMISCENTTRC_ACCDESC = 'Completed' 
                                        AND NRSTMISCENTTRC_DATTIM > '${maxTimestampBefore}'`;
            const deleteResult = await executeSQLAsync(deleteCompletedSql);
            deletedRows = deleteResult?.rowsAffected?.[0] || 0;
            console.log('[Web_HSE] Deleted "Completed" record(s) inserted after "Canceled". Rows affected:', deletedRows);
          } else {
            // Fallback: delete any "Completed" record inserted in the last 5 seconds
            const deleteCompletedSql = `DELETE FROM HSE_NRSTMISCENTTRC 
                                        WHERE NRSTMISCENTTRC_LNK = ${linkFieldValNum} 
                                        AND NRSTMISCENTTRC_ACCDESC = 'Completed' 
                                        AND NRSTMISCENTTRC_DATTIM >= DATEADD(SECOND, -5, GETDATE())`;
            const deleteResult = await executeSQLAsync(deleteCompletedSql);
            deletedRows = deleteResult?.rowsAffected?.[0] || 0;
            console.log('[Web_HSE] Deleted recent "Completed" record(s) (fallback method). Rows affected:', deletedRows);
          }

          // Verify the "Canceled" record exists and check all tracing records
          const verifyCanceledSql = `SELECT TOP 1 NRSTMISCENTTRC_ACCDESC, NRSTMISCENTTRC_DATTIM 
                                     FROM HSE_NRSTMISCENTTRC 
                                     WHERE NRSTMISCENTTRC_LNK = ${linkFieldValNum} 
                                     AND NRSTMISCENTTRC_ACCDESC = 'Canceled' 
                                     ORDER BY NRSTMISCENTTRC_DATTIM DESC`;
          const verifyResult = await executeSQLAsync(verifyCanceledSql);
          const canceledExists = verifyResult?.recordsets?.[0]?.length > 0;
          console.log('[Web_HSE] Verification - "Canceled" record exists:', canceledExists);

          // Check all tracing records for this observation (from table)
          const allTracingSql = `SELECT NRSTMISCENTTRC_ACCDESC, NRSTMISCENTTRC_DATTIM, NRSTMISCENTTRC_LNK 
                                FROM HSE_NRSTMISCENTTRC 
                                WHERE NRSTMISCENTTRC_LNK = ${linkFieldValNum} 
                                ORDER BY NRSTMISCENTTRC_DATTIM DESC`;
          const allTracingResult = await executeSQLAsync(allTracingSql);
          const allRecords = allTracingResult?.recordsets?.[0] || [];
          console.log('[Web_HSE] All tracing records for observation', linkFieldValNum, ':', allRecords);

          // Check if records are visible through the view (what the tab uses)
          const viewTracingSql = `SELECT NRSTMISCENTTRC_ACCDESC, NRSTMISCENTTRC_DATTIM, NrstMiscEntTrc_Lnk 
                                 FROM HSE_NrstMiscEntTrc 
                                 WHERE NrstMiscEntTrc_Lnk = ${linkFieldValNum} 
                                 ORDER BY NRSTMISCENTTRC_DATTIM DESC`;
          try {
            const viewTracingResult = await executeSQLAsync(viewTracingSql);
            const viewRecords = viewTracingResult?.recordsets?.[0] || [];
            console.log('[Web_HSE] Tracing records visible through VIEW HSE_NrstMiscEntTrc:', viewRecords.length, 'records');
            if (viewRecords.length === 0 && allRecords.length > 0) {
              console.error('[Web_HSE] ⚠️ Records exist in table but NOT in view! This indicates a view/field name mismatch.');
              console.error('[Web_HSE] Table has', allRecords.length, 'records, but view returns', viewRecords.length);
            }
          } catch (viewError) {
            console.warn('[Web_HSE] Could not query view HSE_NrstMiscEntTrc:', viewError);
            console.warn('[Web_HSE] This might indicate the view name or field name is different');
          }

          // C++: RefreshScreen("",REFRESH_SELECTED);
          // Refresh after deletion to show the correct tracing records
          // Note: refreshData should refresh both main form and tabs
          refreshData('', 'REFRESH_SELECTED');
          
          // Force multiple refreshes to ensure tab data loads
          // The Tracing tab might need the user to click on it, but we'll try to refresh it
          setTimeout(() => {
            refreshData('', 'REFRESH_SELECTED');
            console.log('[Web_HSE] Second refresh triggered for Tracing tab');
          }, 500);
          
          setTimeout(() => {
            refreshData('', 'REFRESH_SELECTED');
            console.log('[Web_HSE] Third refresh triggered for Tracing tab');
          }, 1500);
          
          if (deletedRows > 0) {
            console.log('[Web_HSE] Successfully removed "Completed" record. Tracing tab should now show "Canceled"');
            console.log('[Web_HSE] If Tracing tab is still empty, please click on the Tracing tab to refresh it');
          }
          
          // Log summary for debugging
          console.log('[Web_HSE] Cancel operation complete. Records in DB:', allRecords.length, 'Canceled records:', allRecords.filter(r => r.NRSTMISCENTTRC_ACCDESC === 'Canceled').length);
        } catch (deleteError) {
          console.warn('[Web_HSE] Could not delete "Completed" record:', deleteError);
          // Still refresh even if deletion failed
          refreshData('', 'REFRESH_SELECTED');
        }
      }, 1000); // Wait 1 second for save to complete

      toast.success('Observation cancelled successfully');
    } catch (error) {
      console.error('[Web_HSE] Error cancelling observation:', error);
      toast.error('Error cancelling observation. Please try again.');
    }
  } catch (error) {
    console.error('[Web_HSE] Error in handleCancelButton:', error);
    toast.error('An error occurred while processing the Cancel action');
  }
}

/**
 * Handle Reward Entry Complete button click
 * RQ_HSM_22_12_25_11_43: Handle Reward Entry Completed Custom Button
 * Implements the logic from NearMissReward::DisplayCustomButtonClicked for NRSTMISCENT_ENTCMPLT (Reward screen)
 * 
 * C++ Reference: NearMissReward::completeNearMissReward
 * This is separate from handleEntryCompleteButton - it's specifically for the Reward screen
 * 
 * @param {string} buttonName - The button name
 * @param {string} screenTag - The screen tag
 * @param {Object} eventObj - The full event object
 * @param {Object} devInterface - Object containing devInterface functions
 */
export async function handleRewardEntryCompleteButton(buttonName, screenTag, eventObj, devInterface) {
  try {
    const { FormSetField, refreshData } = devInterface;
    
    // Check if required functions are available
    if (!FormSetField || !refreshData) {
      console.error('[Web_HSE] Missing required devInterface functions for Reward Entry Complete button');
      toast.error('System error: Required functions not available');
      return;
    }

    // Extract event data
    // C++: CString strSubFormTag(pCustomButtonClicked->SubForm_Tag);
    const { strTabTag, fullRecordArrKeys } = eventObj || {};
    
    // C++: int Count = 0;
    //      if(strSubFormTag == "")
    //      Count = pCustomButtonClicked->pMultiSelectedRows->lCount;
    //      if( Count == 0) {
    //          AfxMessageBox("You must save the Record first");
    //          return false;
    //      }
    // Check if record is saved (must have selected records)
    let recordCount = 0;
    if (!strTabTag || strTabTag === '') {
      // Main form - check if we have selected records (equivalent to pMultiSelectedRows->lCount)
      recordCount = fullRecordArrKeys ? fullRecordArrKeys.length : 0;
    }

    if (recordCount === 0) {
      toast.warning('You must save the Record first');
      return;
    }

    // C++: void NearMissReward::completeNearMissReward(CUSTOMBUTTONCLICKED* pCustomButtonClicked)
    // {
    //     FormSetField("HSE_vwNRSTMISCENT","NRSTMISCENT_RWRDFLG","Y");
    //     RefreshScreen("",REFRESH_SELECTED);
    // }
    
    // Set the reward flag to "Y"
    // C++: FormSetField("HSE_vwNRSTMISCENT","NRSTMISCENT_RWRDFLG","Y");
    FormSetField('HSE_vwNRSTMISCENT', 'NRSTMISCENT_RWRDFLG', 'Y');
    
    // C++: RefreshScreen("",REFRESH_SELECTED);
    refreshData('', 'REFRESH_SELECTED');
    
    // Show success message (separate from entry completed message)
    toast.success('Observation reward entry completed successfully');
    
  } catch (error) {
    console.error('[Web_HSE] Error in handleRewardEntryCompleteButton:', error);
    toast.error('An error occurred while processing the Reward Entry Complete action');
  }
}

/**
 * Handle Entry Complete button click
 * RQ_HSM_22_12_25_09_35: Implement Entry Completed
 * Implements the logic from NearMissEntryCategory::DisplayCustomButtonClicked for NRSTMISCENT_ENTCMPLT
 * 
 * C++ Reference: NearMissEntryCategory::DisplayCustomButtonClicked (lines 29-68)
 * 
 * @param {string} buttonName - The button name
 * @param {string} screenTag - The screen tag
 * @param {Object} eventObj - The full event object
 * @param {Object} devInterface - Object containing devInterface functions
 */
export async function handleEntryCompleteButton(buttonName, screenTag, eventObj, devInterface) {
  try {
    const { FormGetField, executeSQL, executeSQLPromise, getUserName, refreshData } = devInterface;
    
    // Check if required functions are available
    if (!FormGetField || (!executeSQL && !executeSQLPromise) || !getUserName || !refreshData) {
      console.error('[Web_HSE] Missing required devInterface functions for Entry Complete button');
      toast.error('System error: Required functions not available');
      return;
    }
    
    // Prefer executeSQLPromise for async operations, fallback to executeSQL
    const executeSQLAsync = executeSQLPromise || executeSQL;

    // Extract event data
    // C++: CString strSubFormTag(pCustomButtonClicked->SubForm_Tag);
    const { strTabTag, fullRecordArrKeys } = eventObj || {};
    
    // C++: int Count = 0;
    //      if(strSubFormTag == "")
    //      Count = pCustomButtonClicked->pMultiSelectedRows->lCount;
    //      if( Count == 0) {
    //          AfxMessageBox("You must save the Record first");
    //          return false;
    //      }
    // Check if record is saved (must have selected records)
    // Rule: If (Near Miss Confirmation) checkbox [11@600] = "un-checked", then
    let recordCount = 0;
    if (!strTabTag || strTabTag === '') {
      // Main form - check if we have selected records (equivalent to pMultiSelectedRows->lCount)
      recordCount = fullRecordArrKeys ? fullRecordArrKeys.length : 0;
    }

    if (recordCount === 0) {
      toast.warning('You must save the Record first');
      return;
    }

    // Get key field value (Observation number)
    // C++: CString KeyFieldValue = GetKeyField(pCustomButtonClicked->Form_Tag, pCustomButtonClicked->pMultiSelectedRows);
    let observationId = '';
    if (fullRecordArrKeys && fullRecordArrKeys.length > 0) {
      // Get key from selected records (most reliable, equivalent to GetKeyField)
      observationId = fullRecordArrKeys[0].toString();
    } else {
      // Fallback: try to get from form field
      // Try multiple form tags as fallback (view name is more reliable)
      try {
        observationId = FormGetField('HSE_vwNRSTMISCENT', 'NRSTMISCENT_NRSTMISCNUM') || '';
      } catch (e) {
        // Ignore error, try next option
      }
      if (!observationId) {
        try {
          observationId = FormGetField('HSE_TgNrstMiscEnt', 'NRSTMISCENT_NRSTMISCNUM') || '';
        } catch (e) {
          // Ignore error, try next option
        }
      }
      if (!observationId && screenTag) {
        try {
          observationId = FormGetField(screenTag, 'NRSTMISCENT_NRSTMISCNUM') || '';
        } catch (e) {
          // Ignore error
        }
      }
    }
    
    if (!observationId) {
      toast.warning('Unable to find Observation ID. Please save the record first.');
      return;
    }
    
    // RQ-2-2024.14: Update NRSTMISCENT_RPRDSC with NRSTMISCENT_NRSTMISCDESC
    // C++: CString strDescription = FormGetField("HSE_TgNrstMiscEnt","NRSTMISCENT_NRSTMISCDESC");
    //      CString strID=FormGetField("HSE_TgNrstMiscEnt","NRSTMISCENT_NRSTMISCNUM");
    //      CString strSql;
    //      strSql.Format("update HSE_VWNRSTMISCENT set NRSTMISCENT_RPRDSC='%s' where NRSTMISCENT_NRSTMISCNUM=%s",strDescription,strID);
    //      long lRet = ExecuteSQL(strSql);
    
    // Try multiple form tags to get description (view name is more reliable)
    let description = '';
    try {
      description = FormGetField('HSE_vwNRSTMISCENT', 'NRSTMISCENT_NRSTMISCDESC') || '';
    } catch (e) {
      // Ignore error, try next option
    }
    if (!description) {
      try {
        description = FormGetField('HSE_TgNrstMiscEnt', 'NRSTMISCENT_NRSTMISCDESC') || '';
      } catch (e) {
        // Ignore error, try next option
      }
    }
    if (!description && screenTag) {
      try {
        description = FormGetField(screenTag, 'NRSTMISCENT_NRSTMISCDESC') || '';
      } catch (e) {
        // Ignore error - description update is optional
      }
    }

    // Update the RPRDSC field
    if (description) {
      const updateSql = `UPDATE HSE_VWNRSTMISCENT SET NRSTMISCENT_RPRDSC='${description.replace(/'/g, "''")}' WHERE NRSTMISCENT_NRSTMISCNUM=${observationId}`;
      try {
        await executeSQLAsync(updateSql);
      } catch (error) {
        console.error('[Web_HSE] Error updating RPRDSC:', error);
        toast.error('Error updating record description');
        return;
      }
    }

    // C++: bool bNearMissComplete = CompleteNearMiss(pCustomButtonClicked);
    // CompleteNearMiss function:
    //   CString strUserName = GetUserLogin();
    //   CString strSourceScreenName = GetScrCptnByTag(66,pCustomButtonClicked->Form_Tag,"");
    //   CString KeyFieldValue = GetKeyField(pCustomButtonClicked->Form_Tag,pCustomButtonClicked->pMultiSelectedRows);
    //   strSQL.Format("EXECUTE completeNearMissTXN '%s','%s','%s'",KeyFieldValue,strSourceScreenName,strUserName);
    //   long lRet = ExecuteSQL(strSQL);
    //   RefreshScreen("",REFRESH_SELECTED);
    //   if(lRet != 0)
    //       bNearMissComplete  = true;
    
    // Get key field value for the stored procedure
    const keyFieldValue = observationId;
    
    // Get source screen name
    // C++: CString strSourceScreenName = GetScrCptnByTag(66, pCustomButtonClicked->Form_Tag, "");
    // BUG_HSE_HSM_14_3_26_17_33: tracing tab Source Screen must be caption not form tag (desktop uses GetScrCptnByTag).
    const sourceScreenName = getScreenCaption(screenTag) || screenTag || 'Observation Entry';
    
    // Get user name
    // C++: CString strUserName = GetUserLogin();
    const userName = getUserName() || '';
    
    // Execute the completeNearMissTXN stored procedure
    // C++: EXECUTE completeNearMissTXN '%s','%s','%s'
    const storedProcSql = `EXECUTE completeNearMissTXN '${keyFieldValue.replace(/'/g, "''")}','${sourceScreenName.replace(/'/g, "''")}','${userName.replace(/'/g, "''")}'`;
    
    try {
      const result = await executeSQLAsync(storedProcSql);
      
      // C++: RefreshScreen("",REFRESH_SELECTED);
      refreshData('', 'REFRESH_SELECTED');
      
      // Show success message
      toast.success('Observation entry completed successfully');
      
      // C++: Email functionality is commented out, so we skip it here
      // if(bNearMissComplete) {
      //     EMailMsgHandler *eMailMsgHandler = new EMailMsgHandler(m_pCategory);
      //     CString strMailBody = eMailMsgHandler->FormatMailBody(ID_MAIL_Observation_Complete,"");
      //     CString strMsg = m_pCategory->GetHSEObj()->sendMail(strSenderName,strMailSubject,strHSEDepMail,strMailBody,"");
      //     AfxMessageBox(strMsg);
      //     RefreshScreen("",REFRESH_SELECTED);
      // }
      
    } catch (error) {
      console.error('[Web_HSE] Error executing completeNearMissTXN:', error);
      toast.error('Error completing observation entry. Please try again.');
    }
    
  } catch (error) {
    console.error('[Web_HSE] Error in handleEntryCompleteButton:', error);
    toast.error('An error occurred while processing the Entry Complete action');
  }
}

/**
 * RQ_HSE_13_3_26_1_43: Auto-generate a CAR record from a closed observation when Require CAR = Y.
 * C++ ref: NearMissFollowUpCategory::DisplayCustomButtonClicked (lines 69-205)
 * Reads observation form fields, queries policy, inserts into HSE_CRENTRY, copies images, shows toast.
 */
async function generateCARFromObservation(formTag, obsKeyFieldValue, executeSQLAsync, FormGetField, userName) {
  const readField = (field) => {
    try { return (FormGetField(formTag, field) || FormGetField('HSE_vwNRSTMISCENT', field) || '').toString().trim(); }
    catch (_) { return ''; }
  };
  const esc = (v) => (v == null ? '' : String(v).replace(/'/g, "''"));

  const strRequireCAR = readField('NRSTMISCENT_RQRCR');
  if (strRequireCAR !== 'Y') return;

  // CAR Date = today  (YYYY-MM-DD for SQL Server)
  const now = new Date();
  const strCARDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  const strCARYear = String(now.getFullYear());

  // Next CAR number for this year
  const carNumRs = await executeSQLAsync(`SELECT ISNULL(MAX(CRENTRY_CRN)+1, 1) AS NewCARNo FROM HSE_CRENTRY WHERE CRENTRY_CRYR='${esc(strCARYear)}'`);
  const carNumRow = carNumRs?.recordset?.[0] ?? carNumRs?.[0];
  const strCARNo = String(carNumRow?.NewCARNo ?? carNumRow?.newcarno ?? 1);

  // Policy fields
  let CARStatus = '';
  let strCARSource = '';
  try {
    const polRs = await executeSQLAsync(`SELECT HSEOBSRVTN_GnrCrStt, HSEOBSRVTN_CrBss FROM HSE_HSEOBSRVTN`);
    const polRow = polRs?.recordset?.[0] ?? polRs?.[0];
    if (polRow) {
      CARStatus = (polRow.HSEOBSRVTN_GnrCrStt ?? polRow.hseobsrvtn_gnrcrstt ?? '').toString().trim();
      strCARSource = (polRow.HSEOBSRVTN_CrBss ?? polRow.hseobsrvtn_crbss ?? '').toString().trim();
    }
  } catch (_) { /* policy not found – use defaults */ }
  if (CARStatus.length < 2) CARStatus = CARStatus.padStart(2, '0');

  // Owner department from policy
  let strOwnerDept = '';
  try {
    const deptRs = await executeSQLAsync(`SELECT HSEPLC_OWNRDPRT FROM HSE_HSEPLC`);
    const deptRow = deptRs?.recordset?.[0] ?? deptRs?.[0];
    strOwnerDept = (deptRow?.HSEPLC_OWNRDPRT ?? deptRow?.hseplc_ownrdprt ?? '').toString().trim();
  } catch (_) {}

  // Employee (login user employee code – already resolved earlier in handleCloseButton's caller)
  let strEmployee = '';
  try {
    const empRs = await executeSQLAsync(`SELECT EMPLOYEE_NO FROM CMN_EMPLOYEE WHERE EMPLOYEE_USERID = '${esc(userName)}'`);
    const empRow = empRs?.recordset?.[0] ?? empRs?.[0];
    strEmployee = (empRow?.EMPLOYEE_NO ?? empRow?.employee_no ?? '').toString().trim();
  } catch (_) {}

  // Observation fields
  const strNCDescription = readField('NRSTMISCENT_NRSTMISCDESC');
  const strEvidence = readField('NRSTMISCENT_SFTYOBSRV');
  const strSite = readField('NRSTMISCENT_SIT');
  const strLocation = readField('NRSTMISCENT_LOCTYP');
  const strArea = readField('NRSTMISCENT_WRKLOC');
  const strConcernedDepartment = readField('NRSTMISCENT_CNCRNDDEP');
  const strProject = readField('NRSTMISCENT_PRJCT');
  const strTXNYear = readField('NRSTMISCENT_YR');
  const strTXNNo = readField('NRSTMISCENT_NO');

  // CAR Serial No. based on year + source
  let strCARSerialNo = '1';
  try {
    const srlRs = await executeSQLAsync(`SELECT ISNULL(MAX(CRENTRY_CRSRLN)+1, 1) AS SRL FROM HSE_CRENTRY WHERE CRENTRY_CRYR='${esc(strCARYear)}' AND CRENTRY_CRSRC='${esc(strCARSource)}'`);
    const srlRow = srlRs?.recordset?.[0] ?? srlRs?.[0];
    strCARSerialNo = String(srlRow?.SRL ?? srlRow?.srl ?? 1);
  } catch (_) {}

  // C++: temp table for trigger-based tracing during INSERT
  try {
    await executeSQLAsync(`IF OBJECT_ID('tempdb..##TEMP_HSE_TABLE') IS NULL CREATE TABLE ##TEMP_HSE_TABLE(KEYrec VARCHAR(50) NOT NULL, VALUErec VARCHAR(50), CONSTRAINT PK_TEMP_HSE_TABLE PRIMARY KEY CLUSTERED (KEYrec))`);
    await executeSQLAsync(`DELETE FROM ##TEMP_HSE_TABLE`);
    await executeSQLAsync(`INSERT INTO ##TEMP_HSE_TABLE(KEYrec, VALUErec) VALUES('ActionDescription','Creating new CAR')`);
    await executeSQLAsync(`INSERT INTO ##TEMP_HSE_TABLE(KEYrec, VALUErec) VALUES('SrcScreen','Observation Approval')`);
    await executeSQLAsync(`INSERT INTO ##TEMP_HSE_TABLE(KEYrec, VALUErec) VALUES('UserID','${esc(userName)}')`);
  } catch (tmpErr) {
    console.warn('[Web_HSE] CAR generation temp table setup:', tmpErr);
  }

  // INSERT INTO HSE_CRENTRY
  const cols = `CRENTRY_CRDT,CRENTRY_CRYR,CRENTRY_CRN,CRENTRY_CRSTT,CRENTRY_DPR,CRENTRY_NM,CRENTRY_NCDSC,CRENTRY_EVD,CRENTRY_CRPRR,CRENTRY_ST,CRENTRY_LCT,CRENTRY_AR,CRENTRY_CNCDPR,CRENTRY_ATGNR,CRENTRY_CRSRC,CRENTRY_CRSRLN,CRENTRY_TXNYR,CRENTRY_TXNN${strProject ? ',CRENTRY_PRJ' : ''}`;
  const vals = `'${esc(strCARDate)}','${esc(strCARYear)}','${esc(strCARNo)}','${esc(CARStatus)}','${esc(strOwnerDept)}','${esc(strEmployee)}','${esc(strNCDescription)}','${esc(strEvidence)}','m','${esc(strSite)}','${esc(strLocation)}','${esc(strArea)}','${esc(strConcernedDepartment)}','Y','${esc(strCARSource)}','${esc(strCARSerialNo)}','${esc(strTXNYear)}','${esc(strTXNNo)}'${strProject ? `,'${esc(strProject)}'` : ''}`;
  await executeSQLAsync(`INSERT INTO HSE_CRENTRY (${cols}) VALUES (${vals})`);

  // Copy images from observation to CAR
  try {
    const strPicture = readField('NRSTMISCENT_NRSTMISCNUM') || obsKeyFieldValue;
    const prmRs = await executeSQLAsync(`SELECT PrmKy FROM HSE_CRENTRY WHERE CRENTRY_CRDT='${esc(strCARDate)}' AND CRENTRY_CRYR='${esc(strCARYear)}' AND CRENTRY_CRN='${esc(strCARNo)}'`);
    const prmRow = prmRs?.recordset?.[0] ?? prmRs?.[0];
    const strPrmKy = (prmRow?.PrmKy ?? prmRow?.prmky ?? prmRow?.PRMKY ?? '').toString();
    if (strPrmKy) {
      await executeSQLAsync(`EXEC CopyImages 'HSEMS','HSE_VWNRSTMISCENT','NRSTMISCENT_NRSTMISCNUM','${esc(strPicture)}','NRSTMISCENT_OBSRVTNIMG','HSE_CRENTRY','PrmKy','${esc(strPrmKy)}','CRENTRY_NCPHT'`);
    }
  } catch (imgErr) {
    console.warn('[Web_HSE] CopyImages:', imgErr);
  }

  toast.success(`CAR is generated with CAR No. = ${strCARYear}-${strCARNo}`);
}

/**
 * Handle Close button click (Observation Approval / Follow-up).
 * BUG_HSE_HSM_14_3_26: Desktop parity – validations and actions per Observation_Approval_Close_Button_Desktop_Behavior.md
 * (RQ_HSM_22_12_11_28) Handle Close Custom Button
 * Implements NearMissFollowUpCategory::DisplayCustomButtonClicked for NRSTMISCENT_CLS
 * C++ Reference: NearMissFollowUpCategory.cpp DisplayCustomButtonClicked (lines 43-270)
 * @param {string} buttonName - The button name
 * @param {string} screenTag - The screen tag
 * @param {Object} eventObj - The full event object
 * @param {Object} devInterface - Object containing devInterface functions
 */
export async function handleCloseButton(buttonName, screenTag, eventObj, devInterface) {
  // BUG_HSE_HSM_14_3_26: Close button – desktop behaviour (save first, key/employee checks, closeNearMissTXN, refresh)
  try {
    const {
      FormGetField,
      executeSQL,
      executeSQLPromise,
      getUserName,
      refreshData,
      doToolbarAction,
      getEmployeeCodeForLoginUser,
    } = devInterface;

    if (
      !FormGetField ||
      (!executeSQL && !executeSQLPromise) ||
      !getUserName ||
      !refreshData ||
      !doToolbarAction
    ) {
      console.error('[Web_HSE] Missing required devInterface functions for Close button');
      toast.error('System error: Required functions not available');
      return;
    }

    const executeSQLAsync = executeSQLPromise || executeSQL;
    const formTag = screenTag || 'HSE_TGNRSTMISCFLWUP';

    // BUG_HSE_HSM_14_3_26: C++ DoToolBarAction(TOOLBAR_SAVE, Form_Tag, "") – save (validation + persist) before close logic
    doToolbarAction('SAVE', formTag, '');

    const { fullRecord: fullRecordArr, fullRecordArrKeys } = eventObj || {};

    // BUG_HSE_HSM_14_3_26: C++ KeyFieldValue = GetKeyField(strFormTag, pMultiSelectedRows)
    let keyFieldValue = '';
    if (fullRecordArrKeys && fullRecordArrKeys.length > 0) {
      keyFieldValue = fullRecordArrKeys[0].toString();
    } else if (fullRecordArr && fullRecordArr.length > 0) {
      const firstRecord = Array.isArray(fullRecordArr) ? fullRecordArr[0] : fullRecordArr;
      keyFieldValue =
        firstRecord?.NRSTMISCENT_NRSTMISCNUM ||
        firstRecord?.NRSTMISCNUM ||
        '';
    }

    if (!keyFieldValue) {
      try {
        keyFieldValue = FormGetField('HSE_vwNRSTMISCENT', 'NRSTMISCENT_NRSTMISCNUM') || '';
      } catch (e) {
        // ignore
      }
      if (!keyFieldValue) {
        try {
          keyFieldValue = FormGetField(formTag, 'NRSTMISCENT_NRSTMISCNUM') || '';
        } catch (e) {
          // ignore
        }
      }
    }

    // BUG_HSE_HSM_14_3_26: C++ if KeyFieldValue empty: only RefreshScreen (no closeNearMissTXN)
    if (!keyFieldValue) {
      toast.warning('Unable to find Observation number. Please select a record first.');
      refreshData('', 'REFRESH_SELECTED');
      return;
    }

    // BUG_HSE_HSM_14_3_26: C++ strEmployeeName = GetEmployeeCodeForLoginUser(); if empty, only RefreshScreen
    if (typeof getEmployeeCodeForLoginUser === 'function') {
      const employeeCode = await getEmployeeCodeForLoginUser();
      const emp = employeeCode != null && String(employeeCode).trim() !== '' ? String(employeeCode).trim() : '';
      if (emp === '') {
        refreshData('', 'REFRESH_SELECTED');
        return;
      }
    }

    // BUG_HSE_HSM_14_3_26: C++ strSourceScreenName = GetScrCptnByTag(66, strFormTag, "") – use caption for tracing
    let screenName = '';
    const normalizedFormTag = formTag.toUpperCase();
    if (normalizedFormTag === 'HSE_TGNRSTMISCCNFRMTN' || normalizedFormTag.includes('CNFRMTN')) {
      screenName = 'Observation Review';
    } else if (normalizedFormTag === 'HSE_TGNRSTMISCFLWUP' || normalizedFormTag.includes('FLWUP')) {
      screenName = 'Observation Approval';
    } else if (normalizedFormTag === 'HSE_TGNRMISRWARD' || normalizedFormTag.includes('RWARD')) {
      screenName = 'Observation Reward';
    } else {
      screenName = 'Observation Entry';
    }
    const sourceScreenName = getScreenCaption(formTag) || screenName;
    const userName = getUserName() || '';

    const spSql = `EXECUTE closeNearMissTXN '${keyFieldValue.toString().replace(/'/g, "''")}','${userName.replace(/'/g, "''")}','${sourceScreenName.replace(/'/g, "''")}'`;

    try {
      await executeSQLAsync(spSql);

      // RQ_HSE_13_3_26_1_43: C++ CAR auto-generation – client-side INSERT after closeNearMissTXN
      // C++ ref: NearMissFollowUpCategory.cpp lines 69-205
      try {
        await generateCARFromObservation(formTag, keyFieldValue, executeSQLAsync, FormGetField, userName);
      } catch (carErr) {
        console.error('[Web_HSE] Error in CAR auto-generation (observation still closed):', carErr);
      }

      refreshData('', 'REFRESH_SELECTED');
      toast.success('Observation closed successfully');
    } catch (error) {
      console.error('[Web_HSE] Error executing closeNearMissTXN:', error);
      toast.error('Error closing observation. Please try again.');
    }
  } catch (error) {
    console.error('[Web_HSE] Error in handleCloseButton:', error);
    toast.error('An error occurred while processing the Close action');
  }
}

/**
 * Handle Reject Reason screen OK button click
 * C++: CRejectReason::RejectReasonOk() - sets gbUpdateRejectedRecord = true
 * This is called when RJCTRSN_BTN_OK is clicked in the reject reason screen
 * Supports: Observation (rejectObservation), PTW (rejectPTW), Incident (rejectIncident), Risk (rejectRiskAssessment), Site Survey (rejectSitSrvy), Vehicle Accident (updateTXNSts status 3), Awareness (AwrnsPlnRejected), Rescue Plan cancel (cancelRscuPlan) — RQ_HSE_23_3_26_15_42, RQ_HSE_23_3_26_17_05, RQ_HSE_23_3_26_22_44
 * RQ_HSM_22_12_10_50: Handle Reject Custom Button
 * @param {Object} devInterface - Object containing devInterface functions
 */
export async function handleRejectReasonOkButton(devInterface) {
  try {
    if (!pendingRejectObservation) {
      console.warn('[Web_HSE] ⚠ No pending rejection info found. Stored procedure will not execute.');
      return;
    }

    const { moduleType, keyFieldValue, formTag, getUserName, executeSQLAsync, refreshData, toast } = pendingRejectObservation;
    const getU = typeof getUserName === 'function' ? getUserName : (devInterface?.getUserName || (() => ''));
    const userName = (getU() || '').toString().replace(/'/g, "''");
    // BUG_HSE_HSM_14_3_26_17_33: tracing tab Source Screen must be caption not form tag (desktop uses GetScrCptnByTag). Resolve caption here so it is always used.
    let sourceScreenName = (pendingRejectObservation.sourceScreenName || formTag || '').toString();
    const isObservation = !moduleType || moduleType === 'OBSERVATION';
    if (isObservation && formTag && (sourceScreenName.startsWith('HSE_TG') || sourceScreenName === formTag)) {
      sourceScreenName = getScreenCaption(formTag) || sourceScreenName;
    }
    // RQ_HSE_23_3_26_3_36 — Incident / PTW / Risk: if pending stored screen tag, resolve caption for rejectIncident etc.
    // RQ_HSE_23_3_26_15_42 — Awareness Plan Approval caption for tracing
    if (
      ['INCIDENT', 'PTW', 'RISK', 'SITE_SURVEY', 'AWARENESS', 'RESCUE_CANCEL'].includes(moduleType) &&
      formTag &&
      (String(formTag).startsWith('HSE_TG') || String(formTag).startsWith('HSE_Tg'))
    ) {
      sourceScreenName = getScreenCaption(formTag) || sourceScreenName;
    }
    sourceScreenName = sourceScreenName.replace(/'/g, "''");
    const key = keyFieldValue.toString().replace(/'/g, "''");
    const refresh = typeof refreshData === 'function' ? refreshData : devInterface?.refreshData;
    const toastFn = toast || devInterface?.toast;

    let spSql;
    let successMsg;
    const runRefresh = () => { if (refresh) refresh('', 'REFRESH_SELECTED'); };

    switch (moduleType) {
      case 'PTW':
        spSql = `EXECUTE rejectPTW '${key}','${sourceScreenName}','${userName}'`;
        successMsg = `PTW ${keyFieldValue} rejected successfully`;
        break;
      case 'INCIDENT':
        spSql = `EXECUTE rejectIncident '${key}','${sourceScreenName}','${userName}'`;
        successMsg = `Incident ${keyFieldValue} rejected successfully`;
        break;
      case 'RISK':
        spSql = `EXECUTE rejectRiskAssessment '${key}','${sourceScreenName}','${userName}'`;
        successMsg = `Risk assessment ${keyFieldValue} rejected successfully`;
        break;
      // RQ_HSE_23_3_26_22_44 — same argument order as desktop rejectSitSrvy(Key, SourceScreenCaption, User)
      case 'SITE_SURVEY':
        spSql = `EXECUTE rejectSitSrvy '${key}','${sourceScreenName}','${userName}'`;
        successMsg = `Site survey ${keyFieldValue} rejected successfully`;
        break;
      case 'VEHICLE_ACCIDENT':
        spSql = `EXECUTE updateTXNSts '${key}','3','VCLACDNTENT','VCLACDNTENT_VCLACDNTNO'`;
        successMsg = `Vehicle accident ${keyFieldValue} rejected successfully`;
        break;
      case 'POTENTIAL_HAZARD':
        spSql = `EXECUTE updateTXNSts '${key}','3','PTNLHZRDENT','PTNLHZRDENT_PTNLHZRDNO'`;
        successMsg = `Potential hazard ${keyFieldValue} rejected successfully`;
        break;
      case 'LOSS_ACCIDENT':
        spSql = `EXECUTE updateTXNSts '${key}','3','LOSSACDNTENT','LOSSACDNTENT_ACTHZRDNO'`;
        successMsg = `Loss accident ${keyFieldValue} rejected successfully`;
        break;
      // RQ_HSE_23_3_26_15_42: reason text captured in HSE_RJCTRSN via reject reason screen; SP second arg empty string (desktop passes dialog text)
      case 'AWARENESS':
        spSql = `EXECUTE AwrnsPlnRejected ${key},''`;
        successMsg = `Awareness plan ${keyFieldValue} rejected successfully`;
        break;
      // RQ_HSE_23_3_26_17_05: OpenReasonsScr parity — verify at least one reason row exists before cancel (desktop: OpenReasonsScr returns false if COUNT=0)
      case 'RESCUE_CANCEL': {
        const rsnCountSql = `SELECT COUNT(0) AS CNT FROM HSE_RJCTRSN WHERE RJCTRSN_MODULETYPE = 'RSCUPLN-L1' AND RJCTRSN_LINKWITHMAIN = '${key}' AND ISNULL(RJCTRSN_TRACINGLNK, 0) = 0`;
        try {
          const rsnData = await executeSQLAsync(rsnCountSql);
          const rsnRow = rsnData?.recordset?.[0] ?? rsnData?.[0]?.recordset?.[0] ?? rsnData?.[0];
          const rsnCnt = parseInt(rsnRow?.CNT ?? rsnRow?.cnt ?? Object.values(rsnRow || {})[0], 10) || 0;
          if (rsnCnt === 0) {
            console.warn('[Web_HSE] cancelRscuPlan aborted — no reason rows in HSE_RJCTRSN (desktop OpenReasonsScr would return false)');
            if (toastFn && toastFn.warning) toastFn.warning('Cancel aborted — no cancel reason entered.');
            clearPendingRejectObservation();
            return;
          }
        } catch (cntErr) {
          console.warn('[Web_HSE] cancelRscuPlan reason count check failed, proceeding:', cntErr);
        }
        spSql = `EXECUTE cancelRscuPlan '${key}',''`;
        successMsg = `Rescue plan ${keyFieldValue} cancelled successfully`;
        break;
      }
      case 'OBSERVATION':
      default:
        spSql = `EXECUTE rejectObservation '${key}','${sourceScreenName}','${userName}'`;
        successMsg = `Observation ${keyFieldValue} rejected successfully`;
        break;
    }

    console.log('[Web_HSE] Executing reject OK for moduleType:', moduleType, 'SQL:', spSql);
    await executeSQLAsync(spSql);
    console.log('[Web_HSE] ✓ Reject executed successfully');
    runRefresh();
    if (toastFn && toastFn.success) toastFn.success(successMsg);
    clearPendingRejectObservation();
  } catch (error) {
    console.error('[Web_HSE] ✗ Error executing reject:', error);
    if (pendingRejectObservation && (pendingRejectObservation.toast || devInterface?.toast)) {
      const t = pendingRejectObservation.toast || devInterface.toast;
      if (t && t.error) t.error('Error rejecting: ' + (error.message || 'Unknown error'));
    }
    clearPendingRejectObservation();
  }
}

